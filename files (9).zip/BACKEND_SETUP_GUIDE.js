/**
 * REVISEAI - BACKEND API SETUP GUIDE
 * =====================================
 * 
 * Ye guide aapko batata hai ki backend kaise setup karte ho
 * 3 main features ke liye:
 * 1. YouTube transcript extraction
 * 2. Search topic based notes generation
 * 3. Text processing with AI
 */

// ========================
// OPTION 1: NODEJS + EXPRESS
// ========================

/**
 * Installation:
 * npm init -y
 * npm install express cors dotenv axios youtube-transcript-api
 */

const express = require('express');
const cors = require('cors');
const axios = require('axios');
const { getTranscript } = require('youtube-transcript-api');
const app = express();

app.use(cors());
app.use(express.json());

// Load environment variables
require('dotenv').config();

// =====================================
// 1. YOUTUBE TRANSCRIPT EXTRACTION API
// =====================================
app.post('/api/youtube', async (req, res) => {
  try {
    const { url } = req.body;
    
    // Extract video ID from YouTube URL
    const videoId = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\n?#]+)/)[1];
    
    // Get transcript
    const transcript = await getTranscript(videoId);
    const fullText = transcript.map(t => t.text).join(' ');
    
    // Process with AI (using Claude API or your AI service)
    const result = await processWithAI(fullText);
    
    res.json({
      success: true,
      transcript: fullText,
      notes: result.notes,
      flashcards: result.flashcards,
      summary: result.summary
    });
    
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: error.message });
  }
});

// ===================================
// 2. SEARCH TOPIC NOTES GENERATION API
// ===================================
app.post('/api/search', async (req, res) => {
  try {
    const { topic } = req.body;
    
    // Search for content (you can use Google Custom Search, Wikipedia API, etc.)
    const searchResults = await searchContent(topic);
    
    // Process search results with AI
    const result = await processWithAI(searchResults);
    
    res.json({
      success: true,
      topic: topic,
      notes: result.notes,
      flashcards: result.flashcards,
      summary: result.summary
    });
    
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: error.message });
  }
});

// ==========================
// 3. TEXT PROCESSING API
// ==========================
app.post('/api/process-text', async (req, res) => {
  try {
    const { text } = req.body;
    
    // Process text with AI
    const result = await processWithAI(text);
    
    res.json({
      success: true,
      notes: result.notes,
      flashcards: result.flashcards,
      summary: result.summary
    });
    
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: error.message });
  }
});

// ==========================
// AI PROCESSING FUNCTION
// ==========================
async function processWithAI(content) {
  
  // OPTION A: Using Claude API (Recommended)
  const claudeResponse = await axios.post(
    'https://api.anthropic.com/v1/messages',
    {
      model: 'claude-3-sonnet-20240229',
      max_tokens: 2048,
      messages: [
        {
          role: 'user',
          content: `
            Please process this educational content and provide:
            1. Detailed notes with key concepts
            2. 5-7 flashcard questions and answers
            3. A quick summary (5 key points)
            
            Format your response as JSON:
            {
              "notes": "detailed notes here",
              "flashcards": [
                {"q": "question", "a": "answer"},
                ...
              ],
              "summary": "5 key points here"
            }
            
            Content:
            ${content}
          `
        }
      ]
    },
    {
      headers: {
        'x-api-key': process.env.CLAUDE_API_KEY,
        'content-type': 'application/json'
      }
    }
  );

  // Parse Claude response
  const responseText = claudeResponse.data.content[0].text;
  const jsonMatch = responseText.match(/\{[\s\S]*\}/);
  
  if (jsonMatch) {
    return JSON.parse(jsonMatch[0]);
  }
  
  return {
    notes: responseText,
    flashcards: [],
    summary: 'Content processed successfully'
  };
}

// ==========================
// SEARCH CONTENT FUNCTION
// ==========================
async function searchContent(topic) {
  // Option 1: Using Wikipedia API
  try {
    const response = await axios.get('https://en.wikipedia.org/w/api.php', {
      params: {
        action: 'query',
        list: 'search',
        srsearch: topic,
        format: 'json'
      }
    });
    
    if (response.data.query.search.length > 0) {
      const pageTitle = response.data.query.search[0].title;
      
      // Get full page content
      const pageResponse = await axios.get('https://en.wikipedia.org/w/api.php', {
        params: {
          action: 'query',
          titles: pageTitle,
          prop: 'extracts',
          explaintext: true,
          format: 'json'
        }
      });
      
      const pages = pageResponse.data.query.pages;
      const pageId = Object.keys(pages)[0];
      return pages[pageId].extract;
    }
  } catch (error) {
    console.error('Wikipedia search error:', error);
  }
  
  // Fallback: Return default message
  return `Information about ${topic}. Please provide your own content for best results.`;
}

// ==========================
// ERROR HANDLING
// ==========================
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ 
    error: 'Something went wrong',
    message: err.message 
  });
});

// ==========================
// START SERVER
// ==========================
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});

// =============================================
// ENVIRONMENT VARIABLES (.env file)
// =============================================
/*
CLAUDE_API_KEY=your-claude-api-key-here
PORT=5000
NODE_ENV=development
*/

// =============================================
// UPDATED FRONTEND CODE (JavaScript)
// =============================================
/*

// In your HTML file, update the generatePack function:

async function generatePack() {
  const textInput = document.getElementById('textInput').value;
  const youtubeInput = document.getElementById('youtubeInput').value;
  const searchInput = document.getElementById('searchInput').value;

  if (!textInput && !youtubeInput && !searchInput) {
    alert('Please provide some input');
    return;
  }

  document.getElementById('loadingOverlay').classList.add('show');

  try {
    let result;

    if (youtubeInput) {
      result = await fetch('http://localhost:5000/api/youtube', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: youtubeInput })
      }).then(r => r.json());
    } 
    else if (searchInput) {
      result = await fetch('http://localhost:5000/api/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic: searchInput })
      }).then(r => r.json());
    } 
    else if (textInput) {
      result = await fetch('http://localhost:5000/api/process-text', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: textInput })
      }).then(r => r.json());
    }

    // Display results
    displayResults(result);

    document.getElementById('loadingOverlay').classList.remove('show');
    document.getElementById('outputSection').classList.add('active');
    
  } catch (error) {
    console.error('Error:', error);
    alert('Error generating pack: ' + error.message);
    document.getElementById('loadingOverlay').classList.remove('show');
  }
}

function displayResults(result) {
  document.getElementById('notesContent').innerHTML = `<div class="notes-section">${result.notes}</div>`;
  
  let flashcardsHTML = '';
  result.flashcards.forEach((card, index) => {
    flashcardsHTML += `
      <div class="flashcard" onclick="flipFlashcard(this)">
        <div class="flashcard-label">Question</div>
        <div class="flashcard-text" data-question="${card.q}" data-answer="${card.a}">${card.q}</div>
      </div>
    `;
  });
  document.getElementById('flashcardsContent').innerHTML = flashcardsHTML;
  
  document.getElementById('summaryContent').innerHTML = `<div class="notes-section"><strong>Summary:</strong><p>${result.summary}</p></div>`;
}

*/

// =============================================
// PYTHON ALTERNATIVE (Flask)
// =============================================
/*

from flask import Flask, request, jsonify
from flask_cors import CORS
import requests
from youtube_transcript_api import YouTubeTranscriptApi
import os
from dotenv import load_dotenv
import anthropic

load_dotenv()
app = Flask(__name__)
CORS(app)

@app.route('/api/youtube', methods=['POST'])
def youtube_handler():
    try:
        data = request.json
        url = data.get('url')
        
        # Extract video ID
        video_id = url.split('v=')[1].split('&')[0]
        
        # Get transcript
        transcript = YouTubeTranscriptApi.get_transcript(video_id)
        text = ' '.join([item['text'] for item in transcript])
        
        # Process with Claude
        result = process_with_ai(text)
        
        return jsonify({
            'success': True,
            'notes': result['notes'],
            'flashcards': result['flashcards'],
            'summary': result['summary']
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def process_with_ai(content):
    client = anthropic.Anthropic(api_key=os.getenv('CLAUDE_API_KEY'))
    
    message = client.messages.create(
        model="claude-3-sonnet-20240229",
        max_tokens=2048,
        messages=[
            {
                "role": "user",
                "content": f"""
                Process this content and provide notes, flashcards, and summary as JSON:
                
                {content}
                """
            }
        ]
    )
    
    # Parse response and return
    return parse_response(message.content[0].text)

if __name__ == '__main__':
    app.run(debug=True, port=5000)

*/

console.log('✅ Backend setup guide ready!');
console.log('For API keys, contact:');
console.log('- Claude API: https://console.anthropic.com');
console.log('- YouTube Transcript API: https://pypi.org/project/youtube-transcript-api/');
