# ReviseAI - QUICK SETUP & TROUBLESHOOTING GUIDE

## 🎯 KYA FIXED HUA

### ✅ Fixed Features:
1. **YouTube Link Processing** - Ab video link daal sakte ho aur transcript extract hoga
2. **Search Topic Option** - Kisi bhi topic ko search karke notes generate kar sakte ho
3. **Better UI/UX** - Cleaner tabs aur better organization
4. **File Upload** - PDF/DOC files upload kar sakte ho
5. **Flashcard Flip** - Click karke flashcards flip ho sakte hain

---

## 🚀 SETUP STEPS

### Step 1: Frontend (HTML File)
```bash
# bas ye HTML file open karo browser mein
# Demo ke liye kaam kar jayega without backend
reviseai_improved.html
```

### Step 2: Backend Setup (Production ke liye)

#### Option A: Node.js + Express (Recommended)
```bash
# 1. Create project folder
mkdir reviseai-backend
cd reviseai-backend

# 2. Initialize
npm init -y

# 3. Install dependencies
npm install express cors dotenv axios youtube-transcript-api

# 4. Create .env file
echo 'CLAUDE_API_KEY=your_key_here' > .env
echo 'PORT=5000' >> .env

# 5. Copy backend code from BACKEND_SETUP_GUIDE.js
# aur paste karo ek file mein (e.g., server.js)

# 6. Start server
node server.js
```

#### Option B: Python + Flask
```bash
# 1. Create virtual environment
python -m venv venv
source venv/bin/activate  # Mac/Linux
# venv\Scripts\activate   # Windows

# 2. Install dependencies
pip install flask flask-cors python-dotenv anthropic youtube-transcript-api

# 3. Create .env file
echo 'CLAUDE_API_KEY=your_key_here' > .env

# 4. Create server.py from BACKEND_SETUP_GUIDE.js
# aur run karo

# 5. Start server
python server.py
```

---

## 🔑 API KEYS KAISE MILENGE

### 1. Claude API Key
```
Website: https://console.anthropic.com
Login karo apna account se
"Create new API key" button par click karo
Key ko copy karo aur .env mein paste karo
```

### 2. YouTube Transcript API
```
Ye open-source hai, extra API key nahi chahiye
npm ya pip ke through install ho jayega
```

---

## ⚙️ CONFIGURATION

### Frontend Configuration
HTML file ke andar ye change kar sakte ho:

```javascript
// HTML file ke andar iska location check karo
const config = {
  apiKey: '', // Agar API key dena ho
  useClaudAPI: false // true karo jab backend ready ho
};

// CORS issue ho raha hai?
// Backend mein ye add karo:
app.use(cors({
  origin: 'http://localhost:3000', // apna URL
  methods: ['GET', 'POST'],
  credentials: true
}));
```

---

## 🐛 TROUBLESHOOTING

### Issue 1: YouTube Link Working Nahi Ho Raha
```
❌ Problem: Link paste karte hi generate pack nahi ho raha

✅ Solution:
- YouTube link ka format theek hai?
  Correct: https://www.youtube.com/watch?v=dQw4w9WgXcQ
  
- Backend running hai?
  Check: http://localhost:5000/api/youtube
  
- API key add kiya?
  Check: .env mein CLAUDE_API_KEY hai?
```

### Issue 2: CORS Error
```
❌ Problem: Access to XMLHttpRequest blocked by CORS policy

✅ Solution:
Backend mein ye add karo:
const cors = require('cors');
app.use(cors());
```

### Issue 3: API Key Invalid
```
❌ Problem: 401 Unauthorized

✅ Solution:
- API key sahi hai?
  https://console.anthropic.com pe check karo
  
- .env file mein prefix toh nahi lagi?
  CLAUDE_API_KEY=sk-ant-... (theek format)
  
- Server restart kiya?
  CTRL+C karke dobara start karo
```

### Issue 4: File Upload Nahi Ho Raha
```
❌ Problem: File select karte hi kuch nahi hota

✅ Solution:
- Browser console check karo (F12)
  Kya error dikh raha hai?
  
- File size limit check karo
  Max 50MB set hai
  
- File format theek hai?
  Support: PDF, DOC, DOCX, TXT
```

### Issue 5: Search Topic Empty Results
```
❌ Problem: Search topic mein koi results nahi aa rahe

✅ Solution:
- Wikipedia API connect tha?
  Check: https://en.wikipedia.org/api
  
- Topic name theek likha?
  Exact spelling matters!
  
- Internet connection check karo
  Wikipedia API ko internet chahiye
```

---

## 📝 API ENDPOINTS

### YouTube Processing
```
POST /api/youtube
Body: { "url": "https://youtube.com/..." }
Response: { "notes": "...", "flashcards": [...], "summary": "..." }
```

### Search Topic
```
POST /api/search
Body: { "topic": "Photosynthesis" }
Response: { "notes": "...", "flashcards": [...], "summary": "..." }
```

### Text Processing
```
POST /api/process-text
Body: { "text": "Your text here..." }
Response: { "notes": "...", "flashcards": [...], "summary": "..." }
```

---

## 🧪 TESTING

### Frontend Test (without backend)
```
1. HTML file open karo browser mein
2. Text input mein kuch paste karo
3. "Generate Pack" button click karo
4. Sample output dekho (demo data)
```

### Backend Test
```bash
# Node.js mein
curl -X POST http://localhost:5000/api/process-text \
  -H "Content-Type: application/json" \
  -d '{"text": "Hello world"}'

# Python mein
curl -X POST http://localhost:5000/api/process-text \
  -H "Content-Type: application/json" \
  -d '{"text": "Hello world"}'
```

---

## 💡 TIPS & TRICKS

### 1. Better Results Ke Liye
```
- Zyada detailed content provide karo
- Topic specific input de
- YouTube videos academic ho better results
```

### 2. Optimization
```
- Caching add kar sakte ho popular topics ke liye
- Rate limiting add karo spam se bachne ke liye
- Database add karo user progress track karne ke liye
```

### 3. Extension Ideas
```
- PDF export feature
- Multi-language support
- User accounts aur save feature
- Collaborative learning
- Mobile app version
```

---

## 🎓 SAMPLE TOPICS TEST KARNE KE LIYE

```
✓ Photosynthesis
✓ French Revolution
✓ Calculus Integration
✓ World War 2
✓ Quantum Physics
✓ Mitochondria
✓ Shakespeare
✓ Algebra Basics
```

---

## 📞 NEED HELP?

### Check Karo:
1. Browser Console (F12) mein kya error hai
2. Backend logs mein kya error dikha
3. Network tab mein API calls success ho rahe hain?
4. API keys valid hain?

### Common Errors:
- `Cannot find module`: npm install dobara karo
- `EADDRINUSE`: Port already in use, PORT change karo
- `TypeError: Cannot read property`: Check JSON format
- `401 Unauthorized`: API key check karo

---

## 🎯 NEXT STEPS

1. ✅ Frontend file open karo
2. ✅ Backend setup karo (Node.js ya Python)
3. ✅ API keys add karo
4. ✅ Test karo sample content se
5. ✅ Production mein deploy karo

---

**Happy Studying! 🚀**

Agar koi aur issue ho toh ye files dekho:
- reviseai_improved.html (Frontend)
- BACKEND_SETUP_GUIDE.js (Backend code)
